﻿[endpoint: Curiosity.Endpoints.Path("hello")]
[endpoint: Curiosity.Endpoints.EnableMonitoring]
[endpoint: Curiosity.Endpoints.ReadOnly]
[endpoint: Curiosity.Endpoints.AccessMode("AllUsers")]

// await Task.Delay(Random.Shared.Next());
return "hello world";
