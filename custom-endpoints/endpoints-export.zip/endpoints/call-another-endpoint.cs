﻿[endpoint: Curiosity.Endpoints.Path("call-another-endpoint")]
[endpoint: Curiosity.Endpoints.Unauthenticated]

return await RunEndpoint<string>("hello-world");
