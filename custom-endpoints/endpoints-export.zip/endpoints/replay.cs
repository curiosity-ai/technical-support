﻿[endpoint: Curiosity.Endpoints.Path("replay")]

return $"Hello World! You sent: {(Body ?? "Nothing")}";
