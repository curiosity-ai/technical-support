﻿[endpoint: Curiosity.Endpoints.Path("post-chat-message")]
[endpoint: Curiosity.Endpoints.AccessMode("AllUsers")]

var request = Body.FromJson<ChatMessageRequest>();

var finalMessage = $"{request.Message}\nPlease reply in french!";

var messageUID = await ChatAI.AddUserMessageAsync(request.ChatUID, CurrentUser, finalMessage);
await ChatAI.TriggerChatAsync(request.ChatUID, CurrentUser, messageUID, enabledTools: request.Tools);


public class ChatMessageRequest
{
    public string Message { get; set; }
    public UID128 ChatUID { get; set; }
    public UID128 ViewingUID { get; set; }
    public UID128[] Tools { get; set; }
}
