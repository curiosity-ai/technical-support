﻿[endpoint: Curiosity.Endpoints.Path("hello-world")]
[endpoint: Curiosity.Endpoints.Unauthenticated]

return $"Hello World from Curiosity - today is {DateTimeOffset.UtcNow:u}";
